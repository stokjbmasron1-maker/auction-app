-- SCHEMA UNTUK APLIKASI LELANG (AUCTION APP) WITH SUPABASE
-- Silakan salin & jalankan script ini di SQL Editor Supabase Anda.

-- 1. Tabel Profil (Hubungan 1-to-1 dengan auth.users Supabase)
create table public.profiles (
    id uuid references auth.users on delete cascade primary key,
    username text unique not null,
    full_name text,
    avatar_url text,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Aktifkan Row Level Security (RLS) untuk profiles
alter table public.profiles enable row level security;

create policy "Profil dapat dilihat oleh siapa saja" 
    on public.profiles for select 
    using (true);

create policy "Pengguna dapat mengubah profilnya sendiri" 
    on public.profiles for update 
    using (auth.uid() = id);

-- 2. Tabel Barang Lelang (Items)
create table public.items (
    id uuid default gen_random_uuid() primary key,
    title text not null,
    description text,
    category text not null,
    starting_price numeric not null,
    bid_increment numeric not null default 50000.00,
    buy_now_price numeric,
    image_url text,
    seller_id uuid references public.profiles(id) on delete cascade not null,
    end_time timestamp with time zone not null,
    status text not null default 'active' check (status in ('active', 'completed', 'cancelled')),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Aktifkan RLS untuk items
alter table public.items enable row level security;

create policy "Barang lelang dapat dilihat oleh semua orang" 
    on public.items for select 
    using (true);

create policy "Pengguna terautentikasi dapat membuat lelang baru" 
    on public.items for insert 
    with check (auth.uid() = seller_id);

create policy "Penjual dapat memperbarui lelangnya sendiri jika belum ada bid" 
    on public.items for update 
    using (auth.uid() = seller_id);

-- 3. Tabel Riwayat Bid (Bids)
create table public.bids (
    id uuid default gen_random_uuid() primary key,
    item_id uuid references public.items(id) on delete cascade not null,
    bidder_id uuid references public.profiles(id) on delete cascade not null,
    amount numeric not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Aktifkan RLS untuk bids
alter table public.bids enable row level security;

create policy "Riwayat bid dapat dilihat oleh semua orang" 
    on public.bids for select 
    using (true);

create policy "Pengguna terautentikasi dapat menempatkan bid" 
    on public.bids for insert 
    with check (auth.uid() = bidder_id);

-- 4. Fungsi Otomatis: Membuat Profil Baru saat User Mendaftar (Trigger)
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username, full_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 5. Fungsi Database (RPC) untuk Menempatkan Bid Secara Aman (Mencegah Race Condition)
create or replace function public.place_bid(
    p_item_id uuid,
    p_bid_amount numeric
)
returns void as $$
declare
    v_seller_id uuid;
    v_end_time timestamp with time zone;
    v_status text;
    v_starting_price numeric;
    v_bid_increment numeric;
    v_current_highest_bid numeric;
begin
    -- 1. Dapatkan informasi barang lelang
    select seller_id, end_time, status, starting_price, bid_increment
    into v_seller_id, v_end_time, v_status, v_starting_price, v_bid_increment
    from public.items
    where id = p_item_id;

    -- Pastikan barang ada
    if not found then
        raise exception 'Barang lelang tidak ditemukan.';
    end if;

    -- 2. Pastikan lelang masih aktif dan waktu belum habis
    if v_status <> 'active' then
        raise exception 'Barang ini sudah tidak aktif untuk lelang.';
    end if;

    if v_end_time <= now() then
        -- Update status barang menjadi selesai jika waktunya sudah lewat
        update public.items set status = 'completed' where id = p_item_id;
        raise exception 'Waktu lelang untuk barang ini telah berakhir.';
    end if;

    -- 3. Pastikan penawar bukan si penjual itu sendiri
    if v_seller_id = auth.uid() then
        raise exception 'Anda tidak bisa melakukan bid pada barang lelang Anda sendiri.';
    end if;

    -- 4. Dapatkan bid tertinggi saat ini
    select coalesce(max(amount), 0)
    into v_current_highest_bid
    from public.bids
    where item_id = p_item_id;

    -- 5. Validasi jumlah bid
    if v_current_highest_bid = 0 then
        -- Jika belum ada bid, jumlah bid harus >= starting_price
        if p_bid_amount < v_starting_price then
            raise exception 'Bid pertama minimal harus sama dengan harga mulai (% rupiah).', v_starting_price;
        end if;
    else
        -- Jika sudah ada bid, jumlah bid harus >= bid tertinggi + minimal kenaikan bid
        if p_bid_amount < (v_current_highest_bid + v_bid_increment) then
            raise exception 'Jumlah bid minimal harus % rupiah (Bid tertinggi saat ini: % + Kenaikan minimal: %).', 
                (v_current_highest_bid + v_bid_increment), v_current_highest_bid, v_bid_increment;
        end if;
    end if;

    -- 6. Insert data bid baru (TANPA VALIDASI SALDO DOMPET)
    insert into public.bids (item_id, bidder_id, amount)
    values (p_item_id, auth.uid(), p_bid_amount);

end;
$$ language plpgsql security definer;

-- 6. Aktifkan Realtime di Supabase untuk Tabel `bids` dan `items`
alter publication supabase_realtime add table public.bids;
alter publication supabase_realtime add table public.items;
alter publication supabase_realtime add table public.profiles;
