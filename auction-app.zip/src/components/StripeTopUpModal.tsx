import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { motion } from 'framer-motion';
import { X, CreditCard } from 'lucide-react';
import { useCurrency } from '../context/CurrencyContext';
import { supabase } from '../lib/supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

interface CheckoutFormProps {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

const CheckoutForm: React.FC<CheckoutFormProps> = ({ amount, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const { formatPrice, currencyInfo } = useCurrency();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      // 1. Call our local Node server to create a PaymentIntent
      const response = await fetch('http://localhost:3001/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          amount: amount, 
          currency: currencyInfo.code.toLowerCase() 
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Gagal menghubungi server pembayaran");

      const clientSecret = data.clientSecret;

      // 2. Confirm the payment on the client
      const cardElement = elements.getElement(CardElement);
      if (!cardElement) throw new Error("Card element not found");

      const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
        },
      });

      if (stripeError) {
        throw stripeError;
      }

      if (paymentIntent.status === 'succeeded') {
        onSuccess();
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Terjadi kesalahan saat memproses pembayaran.");
    } finally {
      setProcessing(false);
    }
  };

  const cardStyle = {
    style: {
      base: {
        color: '#fff',
        fontFamily: '"Inter", sans-serif',
        fontSmoothing: 'antialiased',
        fontSize: '16px',
        '::placeholder': {
          color: 'rgba(255,255,255,0.4)',
        },
      },
      invalid: {
        color: '#ef4444',
        iconColor: '#ef4444',
      },
    },
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ padding: '16px', background: 'rgba(255,255,255,0.05)', borderRadius: '8px', border: '1px solid var(--bg-dark-700)' }}>
        <CardElement options={cardStyle} />
      </div>

      {error && (
        <div style={{ color: 'var(--danger)', fontSize: '13px', background: 'rgba(239, 68, 68, 0.1)', padding: '10px', borderRadius: '8px' }}>
          {error}
        </div>
      )}

      <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
        <button type="button" onClick={onCancel} className="btn btn-secondary" style={{ flex: 1 }} disabled={processing}>
          Batal
        </button>
        <button type="submit" className="btn btn-primary" disabled={!stripe || processing} style={{ flex: 1 }}>
          {processing ? 'Memproses...' : `Bayar ${formatPrice(amount)}`}
        </button>
      </div>
    </form>
  );
};

export const StripeTopUpModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onTopUpSuccess: (amount: number) => void;
}> = ({ isOpen, onClose, onTopUpSuccess }) => {
  const [topUpAmount, setTopUpAmount] = useState<number | ''>('');
  const [showStripe, setShowStripe] = useState(false);
  const { formatPrice } = useCurrency();

  if (!isOpen) return null;

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (topUpAmount && topUpAmount >= 10000) {
      setShowStripe(true);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.8)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', backdropFilter: 'blur(10px)' }}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }}
        className="glass-panel"
        style={{ width: '100%', maxWidth: '400px', padding: '32px', position: 'relative', boxShadow: '0 20px 40px rgba(0,0,0,0.5)', border: '1px solid var(--bg-dark-700)' }}
      >
        {!showStripe && (
          <button onClick={onClose} style={{ position: 'absolute', top: '16px', right: '16px', background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        )}
        
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{ width: '48px', height: '48px', background: 'rgba(59, 130, 246, 0.1)', color: '#3b82f6', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px auto' }}>
            <CreditCard size={24} />
          </div>
          <h3 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--text-primary)' }}>Top Up Saldo via Stripe</h3>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
            {showStripe ? 'Masukkan detail kartu kredit Anda' : 'Masukkan nominal saldo yang diinginkan'}
          </p>
        </div>

        {!showStripe ? (
          <form onSubmit={handleProceedToPayment} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div className="form-group">
              <label className="form-label">Jumlah Top Up (Min. Rp 10.000)</label>
              <input 
                type="number" 
                className="form-input" 
                value={topUpAmount}
                onChange={(e) => setTopUpAmount(Number(e.target.value) || '')}
                placeholder="Contoh: 100000"
                required
                min="10000"
              />
              {topUpAmount && (
                <div style={{ marginTop: '8px', fontSize: '12px', color: 'var(--success)' }}>
                  Akan dibayar: {formatPrice(Number(topUpAmount))}
                </div>
              )}
            </div>

            <button type="submit" className="btn btn-primary" disabled={!topUpAmount || topUpAmount < 10000} style={{ marginTop: '8px', width: '100%', height: '44px' }}>
              Lanjut ke Pembayaran
            </button>
          </form>
        ) : (
          <Elements stripe={stripePromise}>
            <CheckoutForm 
              amount={topUpAmount as number} 
              onSuccess={() => onTopUpSuccess(topUpAmount as number)} 
              onCancel={() => setShowStripe(false)}
            />
          </Elements>
        )}
      </motion.div>
    </motion.div>
  );
};
