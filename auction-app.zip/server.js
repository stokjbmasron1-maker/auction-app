import express from 'express';
import cors from 'cors';
import Stripe from 'stripe';

const stripe = new Stripe('sk_test_51TgbeR0y8thZ9RLln1uf7UKj3LcUkqktddnxAu33obyHGtwDVvqQGNLOvhbqpP2IyfYroyWFH7RI0ekGSDvEBsfw00ikZzYzgI', {
  apiVersion: '2022-11-15',
});

const app = express();
app.use(cors());
app.use(express.json());

app.post('/create-payment-intent', async (req, res) => {
  try {
    const { amount, currency } = req.body;

    // Create a PaymentIntent with the order amount and currency
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount, // stripe expects lowest denominator (so for IDR it's just the amount)
      currency: currency || 'idr',
      automatic_payment_methods: {
        enabled: true,
      },
    });

    res.send({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    res.status(400).send({ error: error.message });
  }
});

const PORT = 3001;
app.listen(PORT, () => console.log(`Stripe Node server running on port ${PORT}`));
